﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students.Common.Models
{
    public class LectureHall
    {
        public int Id { get; set; }

        public int PlacesCount { get; set; }

        public int Number {  get; set; }

        public int Floor { get; set; }

        public LectureHall()
        {

        }
    }
}
